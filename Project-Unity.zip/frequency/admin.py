from django.contrib import admin
from .models import Frequency

admin.site.register(Frequency)
