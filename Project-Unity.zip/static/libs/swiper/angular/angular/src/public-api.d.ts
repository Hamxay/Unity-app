export * from './swiper.module';
export * from './swiper.component';
export * from './swiper-slide.directive';
