from django.contrib import admin
from .models import Report

admin.site.register(Report)
