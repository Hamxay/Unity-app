from django.urls import path
from rest_framework import routers
from .views import (
    ScheduleListView,
    ScheduleCreateView,
    ScheduleDeleteView,
    ScheduleUpdateView,
    HistoricalScheduleListView,
    HistoricalScheduleUpdateView
)
from .viewsets import ScheduleViewset, ScheduleHistoryViewset

router = routers.DefaultRouter()
router.register("Schedule", ScheduleViewset, basename="Schedule")
router.register(
    "Schedule/history",
    ScheduleHistoryViewset,
    basename="Schedule_history",
)

app_name = "Schedule"

urlpatterns = [
    path("list/", ScheduleListView.as_view(), name="Schedule_list"),
    path("create/", ScheduleCreateView.as_view(), name="Schedule_create"),
    path(
        "update/<int:pk>/",
        ScheduleUpdateView.as_view(),
        name="Schedule_update",
    ),
    path(
        "delete/<int:pk>/",
        ScheduleDeleteView.as_view(),
        name="Schedule_delete",
    ),
    path(
        "history/list/<int:pk>/",
        HistoricalScheduleListView.as_view(),
        name="historicalSchedule_list",
    ),
    path(
        "history/update/<int:pk>/",
        HistoricalScheduleUpdateView.as_view(),
        name="historicalSchedule_update",
    ),
]
