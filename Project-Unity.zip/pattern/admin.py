from django.contrib import admin
from pattern.models import LoadPattern

admin.site.register(LoadPattern)
