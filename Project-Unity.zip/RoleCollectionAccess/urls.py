from django.urls import path
from rest_framework import routers
from .views import RoleCollectionAccessListView, RoleCollectionAccessCreateView, RoleCollectionAccessUpdateView, RoleCollectionAccessDeleteView
from .viewsets import RoleCollectionAccessViewset

router = routers.DefaultRouter()
router.register("RoleCollectionAccess", RoleCollectionAccessViewset, basename="RoleCollectionAccess")

app_name = "RoleCollectionAccess"

urlpatterns = [
    path("list/", RoleCollectionAccessListView.as_view(), name="RoleCollectionAccess_list"),
    path("create/", RoleCollectionAccessCreateView.as_view(), name="RoleCollectionAccess_create"),
    path("update/<int:pk>/", RoleCollectionAccessUpdateView.as_view(), name="RoleCollectionAccess_update", ),
    path("delete/<int:pk>/", RoleCollectionAccessDeleteView.as_view(), name="RoleCollectionAccess_delete", ),

]
