from django.contrib import admin
from .models import RoleCollectionAccess

admin.site.register(RoleCollectionAccess)
