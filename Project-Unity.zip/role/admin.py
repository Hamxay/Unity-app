from django.contrib import admin
from .models import Role

admin.site.register(Role)
